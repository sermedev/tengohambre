--
-- PostgreSQL database dump
--

\restrict Q4sSaRLYroIXgjILtAY7VKh3qIm6YX3KPHdSLK6X1EgOaNS6kgsG7yviJsZ8CW5

-- Dumped from database version 17.12
-- Dumped by pg_dump version 17.12 (Debian 17.12-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: households; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.households (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text DEFAULT 'Mi casa'::text NOT NULL,
    invite_code text DEFAULT upper(substr(replace((gen_random_uuid())::text, '-'::text, ''::text), 1, 8)) NOT NULL,
    created_by uuid DEFAULT auth.uid(),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: create_household(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_household(p_name text DEFAULT 'Mi casa'::text) RETURNS public.households
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
                                                                                                                                                                                                                            declare h public.households;
                                                                                                                                                                                                                            begin
                                                                                                                                                                                                                              if auth.uid() is null then raise exception 'Hay que iniciar sesión'; end if;
                                                                                                                                                                                                                                insert into public.households (name, created_by) values (coalesce(nullif(trim(p_name), ''), 'Mi casa'), auth.uid()) returning * into h;
                                                                                                                                                                                                                                  insert into public.household_users (household_id, user_id, role) values (h.id, auth.uid(), 'admin');
                                                                                                                                                                                                                                    return h;
                                                                                                                                                                                                                                    end $$;


--
-- Name: is_household_member(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_household_member(hid uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
                        select exists (select 1 from public.household_users where household_id = hid and user_id = auth.uid());
                        $$;


--
-- Name: join_household(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.join_household(p_code text) RETURNS public.households
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
                                                                                                                                                                                                                                    declare h public.households;
                                                                                                                                                                                                                                    begin
                                                                                                                                                                                                                                      if auth.uid() is null then raise exception 'Hay que iniciar sesión'; end if;
                                                                                                                                                                                                                                        select * into h from public.households where invite_code = upper(trim(p_code));
                                                                                                                                                                                                                                          if h.id is null then raise exception 'Código no válido'; end if;
                                                                                                                                                                                                                                            insert into public.household_users (household_id, user_id) values (h.id, auth.uid()) on conflict do nothing;
                                                                                                                                                                                                                                              return h;
                                                                                                                                                                                                                                              end $$;


--
-- Name: ping(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ping() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 'pong'::text;
  $$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                                                                                                                                                                                                begin new.updated_at = now(); return new; end $$;


--
-- Name: foods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.foods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    brand text,
    store text,
    barcode text,
    kcal numeric(6,1),
    protein_g numeric(5,1),
    carbs_g numeric(5,1),
    sugars_g numeric(5,1),
    fat_g numeric(5,1),
    sat_fat_g numeric(5,1),
    fiber_g numeric(5,1),
    salt_g numeric(5,2),
    source text DEFAULT 'etiqueta'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foods_source_check CHECK ((source = ANY (ARRAY['etiqueta'::text, 'open_food_facts'::text])))
);


--
-- Name: household_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.household_users (
    household_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text DEFAULT 'miembro'::text NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT household_users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'miembro'::text])))
);


--
-- Name: meal_plan_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plan_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    day date NOT NULL,
    meal text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    recipe_id uuid,
    pantry_item_id uuid,
    eat_out text,
    portions jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    label text,
    CONSTRAINT meal_plan_items_check CHECK (((num_nonnulls(recipe_id, pantry_item_id, eat_out, label) >= 1) AND ((eat_out IS NULL) OR ((recipe_id IS NULL) AND (pantry_item_id IS NULL))))),
    CONSTRAINT meal_plan_items_eat_out_check CHECK ((eat_out = ANY (ARRAY['ligero'::text, 'normal'::text, 'copioso'::text]))),
    CONSTRAINT meal_plan_items_meal_check CHECK ((meal = ANY (ARRAY['des'::text, 'mm'::text, 'com'::text, 'mer'::text, 'cen'::text])))
);


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    color text DEFAULT '--p1'::text NOT NULL,
    icon text,
    sex text NOT NULL,
    birth_date date NOT NULL,
    is_kid boolean DEFAULT false NOT NULL,
    default_portion numeric(3,2) DEFAULT 1 NOT NULL,
    goal text DEFAULT 'mantener'::text NOT NULL,
    activity text DEFAULT 'baja'::text NOT NULL,
    height_cm numeric(5,1),
    waist_cm numeric(5,1),
    sports jsonb DEFAULT '[]'::jsonb NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT members_default_portion_check CHECK (((default_portion >= (0)::numeric) AND (default_portion <= (2)::numeric))),
    CONSTRAINT members_sex_check CHECK ((sex = ANY (ARRAY['hombre'::text, 'mujer'::text, 'nino'::text, 'nina'::text])))
);


--
-- Name: menu_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pantry_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pantry_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    place text NOT NULL,
    qty numeric(7,2) DEFAULT 1 NOT NULL,
    unit text DEFAULT 'ud'::text NOT NULL,
    recipe_id uuid,
    expires_on date,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    added_on date DEFAULT CURRENT_DATE NOT NULL,
    CONSTRAINT pantry_items_place_check CHECK ((place = ANY (ARRAY['Despensa'::text, 'Nevera'::text, 'Congelador'::text]))),
    CONSTRAINT pantry_items_qty_check CHECK ((qty >= (0)::numeric)),
    CONSTRAINT pantry_items_unit_check CHECK ((unit = ANY (ARRAY['raciones'::text, 'g'::text, 'kg'::text, 'ud'::text, 'L'::text, 'paquetes'::text])))
);


--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_ingredients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    food_ref text NOT NULL,
    name text NOT NULL,
    grams numeric(7,1) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    CONSTRAINT recipe_ingredients_grams_check CHECK ((grams >= (0)::numeric))
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    kind text DEFAULT 'receta'::text NOT NULL,
    food_id uuid,
    servings numeric(4,1) DEFAULT 4 NOT NULL,
    minutes integer,
    meals text[] DEFAULT '{}'::text[] NOT NULL,
    groups text[] DEFAULT '{}'::text[] NOT NULL,
    steps text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    icon text DEFAULT '🍽️'::text NOT NULL,
    note text,
    kid_friendly boolean DEFAULT true NOT NULL,
    portion_g numeric(6,1),
    pack_portions numeric(4,1),
    suggested_key text,
    CONSTRAINT recipes_kind_check CHECK ((kind = ANY (ARRAY['receta'::text, 'precocinado'::text]))),
    CONSTRAINT recipes_servings_check CHECK ((servings > (0)::numeric))
);


--
-- Name: saved_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    section text NOT NULL
);


--
-- Name: shopping_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    section text DEFAULT 'Despensa'::text NOT NULL,
    qty numeric(7,2),
    unit text,
    checked boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    from_menu boolean DEFAULT false NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: weight_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weight_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    member_id uuid NOT NULL,
    day date DEFAULT CURRENT_DATE NOT NULL,
    weight_kg numeric(5,2),
    waist_cm numeric(5,1)
);


--
-- Data for Name: foods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.foods (id, household_id, name, brand, store, barcode, kcal, protein_g, carbs_g, sugars_g, fat_g, sat_fat_g, fiber_g, salt_g, source, updated_at) FROM stdin;
\.


--
-- Data for Name: household_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.household_users (household_id, user_id, role, joined_at) FROM stdin;
ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	14e6fa9a-6fad-42be-abf8-352fb1b1fa39	admin	2026-11-21 15:06:51.178026+00
ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	de383191-914e-4d7c-8c2f-4b7cc6fa6ebd	miembro	2026-11-22 08:26:28.933922+00
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.households (id, name, invite_code, created_by, created_at) FROM stdin;
ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Casa	3141C4CC	14e6fa9a-6fad-42be-abf8-352fb1b1fa39	2026-11-21 15:06:51.178026+00
\.


--
-- Data for Name: meal_plan_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meal_plan_items (id, household_id, day, meal, "position", recipe_id, pantry_item_id, eat_out, portions, updated_at, label) FROM stdin;
3ed9df52-a60c-4b78-bcda-8c960b1f93b7	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	com	3	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 19:17:00.898278+00	\N
c04a3900-c5a8-4dbe-9305-b80f2a961d5a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-29	com	3	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 15:12:48.704856+00	\N
049d7333-dcd1-4a66-85db-861044f70167	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-22	cen	0	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	\N	\N	{}	2026-11-22 10:27:32.652918+00	\N
01f254a7-35a6-4961-982c-7c389ea51c0e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-22	cen	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 10:27:38.695402+00	\N
fc9aecd1-3e1d-4f60-aff1-3ea70ddc0ed6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	cen	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 10:27:42.575723+00	\N
a55456cf-d564-4378-93c3-58f3c108f9ba	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	des	0	b49842f8-23b8-44bd-896d-a8e4dee42e39	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-21 21:01:28.7526+00	\N
1aebd1cf-91a5-411f-ac1c-27f0af46ada3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-24	com	3	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	\N	\N	{}	2026-11-22 19:17:14.231784+00	\N
5f3d4235-1b33-45b6-b0f4-ff03d90b8c5c	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	cen	2	b6e6f46d-a407-42c0-a184-5c4d5b18b746	\N	\N	{}	2026-11-22 10:27:52.430824+00	\N
f1781332-b744-4e28-ac47-e2c0a5375851	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-18	cen	0	e6108671-8cd3-497a-ad92-8efd5b2af6f3	\N	\N	{}	2026-11-22 15:20:56.099776+00	\N
4ba02908-84b9-4bc0-b1e4-6ea6fb1e31c9	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-21	des	0	b49842f8-23b8-44bd-896d-a8e4dee42e39	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-21 21:01:48.992327+00	\N
665c94d4-09a2-41dd-b309-5d7894111bf7	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-19	des	0	b49842f8-23b8-44bd-896d-a8e4dee42e39	\N	\N	{}	2026-11-22 07:59:52.032967+00	\N
f0c2418d-23ee-49e8-9984-d87a34e76b36	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-26	cen	1	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	\N	\N	{}	2026-11-22 15:30:26.924051+00	\N
0a5a311b-910d-45c7-9d56-036f6094c12e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-22	des	0	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 08:02:35.5396+00	\N
c22ef423-e54b-41fe-9a10-98bcd239a9cf	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	des	1	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 08:07:43.389187+00	\N
a4574389-2278-4bac-8b3c-fe48527d0c23	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-17	des	0	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 08:07:47.498304+00	\N
8e424342-0522-436a-95dc-3e833de656cb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-18	des	0	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 08:07:57.193335+00	\N
984fe092-09f4-4797-a778-f06bec9219a0	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	cen	0	3c873515-bfa4-41ac-97de-7ba908a8e4a7	\N	\N	{}	2026-11-22 08:12:19.406052+00	\N
6cdda48c-5932-4baa-bc58-afe4bd21241e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	cen	1	7b820557-5377-4c59-a56b-ad58703ab091	\N	\N	{}	2026-11-22 08:12:24.321924+00	\N
5c867232-b792-4fa0-befd-bdb86c64233b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-17	com	0	14fecc26-bc6f-4056-9da6-37e479d46d3b	\N	\N	{}	2026-11-22 08:14:29.990257+00	\N
aa405ca0-74ad-4311-9b6e-69db032d9d0b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-18	com	0	3e0e8fc2-b3d9-4af5-bbcd-716813728f87	\N	\N	{}	2026-11-22 08:14:32.381447+00	\N
91a17837-d50e-45a0-8b7d-88ccc52a45bd	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-19	com	0	d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6	\N	\N	{}	2026-11-22 08:21:48.202628+00	\N
4cf48b6e-f9da-4182-bff1-60f78b459684	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	cen	0	ba6162e3-4267-4312-b0d9-f2b9a4f0a191	\N	\N	{}	2026-11-22 08:57:48.809213+00	\N
b86e5e27-b3fd-4ef6-8c79-7fa58f3bdc28	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-17	cen	0	4f79bc5d-4f62-474b-bc9e-fc731584dfce	\N	\N	{}	2026-11-22 09:57:44.138486+00	\N
8952b6a6-d4f6-45f5-a4af-dfe94116562f	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	com	0	9d5e5174-db78-4ad7-909f-8642d6c84a7d	\N	\N	{}	2026-11-22 10:08:54.574354+00	\N
6e80b948-47cf-408f-8a0b-0c3694128535	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	com	0	8d1ccede-f5e5-484c-a8bf-a849646d916d	\N	\N	{}	2026-11-22 10:08:57.468565+00	\N
6532930b-f7db-4c95-8aa6-6c7c333aa7cb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-21	cen	0	49fff483-3a00-4611-addf-7028e500a5cc	\N	\N	{}	2026-11-22 10:09:34.353928+00	\N
9e073e04-9d5f-4460-9406-6f1d3f5ac6cb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	com	1	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 10:14:37.360412+00	\N
144d47f4-86bf-48dc-a9f2-8bbdd7f74d47	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-17	com	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 10:14:41.050199+00	\N
d62e9e4b-98f6-4023-8b10-be1818689a82	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-18	com	1	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 10:14:45.272693+00	\N
aa1fc696-c9c0-4b0c-aa00-90f9423016e9	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-19	com	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 10:14:47.985301+00	\N
4600d999-3612-4020-8057-0b1c56294dbd	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	com	1	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 10:14:50.963851+00	\N
479b8b56-c18b-41d1-a88b-ed83aaef3da0	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	mm	0	7891a809-607e-45b7-8e39-4151c9571713	\N	\N	{}	2026-11-22 10:21:00.933154+00	\N
8755fb7b-f726-4d1e-b871-36fb2a7f96fd	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	mm	1	44d2391a-55b3-4fff-8161-57faf0b189f7	\N	\N	{}	2026-11-22 10:21:06.624578+00	\N
1bde86f1-4c05-4802-a533-7267e302d8d1	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-17	mm	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:04:16.455134+00	\N
cddebdfb-67ab-43b9-a5bd-cecf90947b5b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-22	com	0	4b7ceedb-3445-48f5-8e2a-3a18893081fe	\N	\N	{}	2026-11-22 10:30:08.367314+00	\N
0dad2a29-43db-4568-b72c-57b6b450d9af	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-22	com	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 10:30:10.04896+00	\N
d66afded-2a2e-48e8-8e00-8c9c697ba885	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-21	com	0	163d1a0c-1573-4334-bad9-92078e5cbdc8	\N	\N	{}	2026-11-22 10:33:21.42074+00	\N
c47cd9e6-bf0a-49a1-a331-696a5def7630	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-21	com	1	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	\N	\N	{}	2026-11-22 10:34:15.423821+00	\N
90dd3c0c-5c8b-4b54-898a-20e0d0285cac	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-22	mm	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 10:34:36.420689+00	\N
8cde36c5-11a8-43ad-8d87-d4752042a235	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-16	mer	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 10:38:08.823767+00	\N
7f9901df-2813-4e82-8804-d017aef30219	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-18	mer	0	7891a809-607e-45b7-8e39-4151c9571713	\N	\N	{}	2026-11-22 10:38:18.912922+00	\N
4d1359f4-7545-442c-99cb-4e2f68670d33	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-21	mer	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 10:38:26.502404+00	\N
c46677cc-ad4a-4ed3-8862-81a0810e0f6f	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-17	mer	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{}	2026-11-22 10:38:37.343071+00	\N
ad4f9dcb-b503-4719-ad31-9f91fcc0bdbb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	mer	0	434dbeb2-743b-47d5-a54d-ced650218678	\N	\N	{}	2026-11-22 10:38:40.065214+00	\N
0c911f0f-4000-4842-8203-b61f690cdb41	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-22	mer	0	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 10:38:42.242349+00	\N
5cfcc8b6-d9d7-43d9-8683-4cb142d149ae	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-19	mer	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{}	2026-11-22 10:38:44.822918+00	\N
5f44acd6-f15b-4630-9e78-cbbf86c249c1	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-18	mm	0	434dbeb2-743b-47d5-a54d-ced650218678	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:04:38.366561+00	\N
f406c61d-749d-4e9e-8fbc-e43595d3912c	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-19	mm	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:04:52.521733+00	\N
8db0b11c-a34f-4cf1-a59c-d1759c93750a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-21	mm	0	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:05:31.519944+00	\N
eca9f6a0-f470-4808-9642-cc7f95ad93f5	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-18	cen	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 15:21:05.988589+00	\N
6255c589-9721-4c2b-8465-f7e08a0d2b58	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-25	cen	2	d3afbd1e-ef86-4e18-9287-91367876235a	\N	\N	{}	2026-11-22 15:28:42.291595+00	\N
6f013e45-d5a6-418b-849e-3f5c8792d345	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-25	cen	3	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	\N	\N	{}	2026-11-22 15:28:49.880391+00	\N
8d157f00-eb4f-482d-a63f-cb74de919d82	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	com	2	14fecc26-bc6f-4056-9da6-37e479d46d3b	\N	\N	{}	2026-11-22 19:16:38.810145+00	\N
d23cd39d-4791-430f-bd91-4ff7187bf673	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-24	com	2	9d5e5174-db78-4ad7-909f-8642d6c84a7d	\N	\N	{}	2026-11-22 19:16:47.984878+00	\N
0fd21719-f5a5-44a7-b0df-32f5248d7972	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	cen	0	3c873515-bfa4-41ac-97de-7ba908a8e4a7	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
b602fff4-3714-493c-b324-35ddaffda6a3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	mm	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:05:07.386113+00	\N
a28f3db7-3ab0-4e4f-a780-96d23041d7eb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-20	mm	1	44d2391a-55b3-4fff-8161-57faf0b189f7	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:05:18.678131+00	\N
71350979-fc4f-4e50-8946-499a03341b7d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	mer	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
d6e5ea71-f11a-45f6-ac22-c9ef9ccbe657	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	mm	0	7891a809-607e-45b7-8e39-4151c9571713	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
1650b0d3-ffeb-453f-a81a-28f5622d88ce	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	cen	1	7b820557-5377-4c59-a56b-ad58703ab091	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
da02266b-9d63-408e-b70d-442662a9dc21	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	des	0	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
044692c7-a5e4-4157-817f-ac4ce64467cd	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	mm	1	44d2391a-55b3-4fff-8161-57faf0b189f7	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
307e2974-eb39-4c6f-b65c-f5a525196362	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-23	cen	2	b6e6f46d-a407-42c0-a184-5c4d5b18b746	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
ed6d83a3-de9c-4462-b969-a9f8c27fc85a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-24	cen	0	4f79bc5d-4f62-474b-bc9e-fc731584dfce	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
43332009-1827-429f-a115-ad61629a36e4	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-24	des	0	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
2cdf4953-68c9-43a2-8d15-98d586ec25c2	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-24	mer	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
98d479fe-1f5a-4fea-9700-580a27df74b5	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-24	mm	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
d819fe39-479b-4698-bc94-18a1ac82f301	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-25	com	0	3e0e8fc2-b3d9-4af5-bbcd-716813728f87	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
9ffdbd89-516b-42dd-9b20-201b7c69cfc8	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-25	des	0	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
7403f073-38b1-4f77-96cf-f942f3b3ac3d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-25	mer	0	7891a809-607e-45b7-8e39-4151c9571713	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
3e6d9f6f-9c29-4c25-942a-53e45f4517f2	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-25	mm	0	434dbeb2-743b-47d5-a54d-ced650218678	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
38c77063-4f0d-48d8-9f86-7a8df617fe7d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-25	com	1	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
ad884381-c8a5-429a-9421-9b9925b180c9	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-26	com	0	d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
5a857d0c-8140-4a91-8116-177399b80449	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-26	des	0	b49842f8-23b8-44bd-896d-a8e4dee42e39	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
4aa358ab-1e5b-40d7-a8ee-2579fce98dff	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-26	mer	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
0e46dcb3-ed9b-4847-91d4-27d541cb8fa3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-26	mm	0	cd348be5-c20d-4254-99cf-758c0911e060	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
0aadee90-38ba-4a36-86bd-ad36afe8c834	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-26	com	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
2ce6df9b-b0b0-4a71-ba84-ebd953f8f461	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	com	0	8d1ccede-f5e5-484c-a8bf-a849646d916d	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
8b8bcc43-5ded-479a-974b-94ab416b5265	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	des	0	b49842f8-23b8-44bd-896d-a8e4dee42e39	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
62311e31-7082-4031-a15c-3a0e0c55f17e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	mer	0	434dbeb2-743b-47d5-a54d-ced650218678	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
5ab08e1e-ce67-4b2b-aed4-1e54bffb24ef	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	mm	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
6019db52-7167-4db1-a748-cb4464af35e7	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	com	1	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
7d849d68-fc3e-4395-b8aa-65598eb157a1	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	mm	1	44d2391a-55b3-4fff-8161-57faf0b189f7	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
84ebdd5f-fe54-4543-8ec1-c168fc058cdd	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-28	com	0	163d1a0c-1573-4334-bad9-92078e5cbdc8	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
bfece8b5-810a-4f73-9bce-65cd1a0ef595	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-28	des	0	b49842f8-23b8-44bd-896d-a8e4dee42e39	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
dd4efbc4-e330-4eba-9e27-02d5e79592fa	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-28	mer	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
bb5ccbca-4637-4d63-b517-3e7cfdb23ad6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-28	mm	0	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	\N	\N	{"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}	2026-11-22 15:12:16.271049+00	\N
e2cbe249-7823-406c-bef8-408fac8a9e13	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-28	com	1	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
34046d39-b2db-4f55-999e-e09ba5485bea	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-29	cen	0	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
ac704781-1555-44d9-b703-932774ae40d8	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-29	des	0	89bb2ccc-7818-4507-9334-73ab0a850fe6	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
2d6fde21-23ca-46bf-bc7d-2fb45cbeb7c3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-29	mer	0	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
398193f1-2ca0-4afc-a96a-95845848666d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-29	mm	0	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
9b488387-e6b0-4c06-b943-767a98c7dd75	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-29	cen	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 15:12:16.271049+00	\N
1fde2c9e-1943-420e-b254-e7a57dcfcc65	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-19	cen	0	8a0c6535-fd4a-4918-bc5f-d2d3c866a151	\N	\N	{}	2026-11-22 15:21:36.687923+00	\N
96a938ad-eb2d-407c-b9b0-42bd4e6a0244	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	cen	0	ba6162e3-4267-4312-b0d9-f2b9a4f0a191	\N	\N	{}	2026-11-22 15:26:20.396625+00	\N
6c65f4a0-c9fd-43aa-b76d-da2d7a1f442f	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-27	cen	1	a0015d7d-1c23-42ad-b98d-bb3e1596451f	\N	\N	{}	2026-11-22 15:26:22.098744+00	\N
f366b00d-437b-4a37-b831-818623e91a57	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-28	cen	2	3f6e65ea-66a6-421d-9ea7-6bd118219d40	\N	\N	{}	2026-11-22 15:28:35.111162+00	\N
8031c0c1-4b53-403e-b176-f5f9ace306f0	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-29	com	2	a2cbaa67-6ca0-4758-8f34-dab33fd25c21	\N	\N	{}	2026-11-22 15:12:34.653306+00	\N
0ceec61d-58a8-49e8-85f5-522db273f275	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-19	cen	1	77a3a5d9-8564-4d04-9bda-e70169882025	\N	\N	{}	2026-11-22 15:21:42.514567+00	\N
d04b3cfa-74f8-45b2-9066-d87defa230ee	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	2026-11-26	cen	0	8a0c6535-fd4a-4918-bc5f-d2d3c866a151	\N	\N	{}	2026-11-22 15:30:21.28551+00	\N
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, household_id, name, color, icon, sex, birth_date, is_kid, default_portion, goal, activity, height_cm, waist_cm, sports, "position", updated_at) FROM stdin;
d6d9d46b-1895-470d-85d2-413cf70e83a9	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Mamá	--p2	\N	mujer	1983-01-29	f	0.80	mantener	baja	\N	\N	[]	1	2026-11-21 15:06:51.389804+00
0a416451-d5e0-479a-81d5-94da06c63548	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Fabio	--p3	\N	nino	2018-07-05	t	0.70	crecer	baja	\N	\N	[]	2	2026-11-21 15:06:51.389804+00
bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Sergio	--p4	\N	nino	2020-03-25	t	0.60	crecer	baja	\N	\N	[]	3	2026-11-21 15:06:51.389804+00
c525a08d-787a-4cb9-b7a8-548a140ce0f2	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Papá	--p1	🧔	hombre	1984-03-21	f	1.00	musculo	baja	172.0	\N	[{"days": 3, "sport": "crossfit", "minutes": 60}]	0	2026-11-21 20:52:12.059368+00
\.


--
-- Data for Name: menu_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_templates (id, household_id, name, items, created_at, updated_at) FROM stdin;
6f879701-4a3b-4310-ac11-77b8a94f6685	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Menú 1	[{"dow": 0, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "3c873515-bfa4-41ac-97de-7ba908a8e4a7"}, {"dow": 0, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "7b820557-5377-4c59-a56b-ad58703ab091"}, {"dow": 0, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 2, "recipe_id": "b6e6f46d-a407-42c0-a184-5c4d5b18b746"}, {"dow": 0, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "9d5e5174-db78-4ad7-909f-8642d6c84a7d"}, {"dow": 0, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 0, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 0, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 0, "meal": "mm", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "7891a809-607e-45b7-8e39-4151c9571713"}, {"dow": 0, "meal": "mm", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "44d2391a-55b3-4fff-8161-57faf0b189f7"}, {"dow": 1, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "4f79bc5d-4f62-474b-bc9e-fc731584dfce"}, {"dow": 1, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "14fecc26-bc6f-4056-9da6-37e479d46d3b"}, {"dow": 1, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 1, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 1, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 1, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 2, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "8a0c6535-fd4a-4918-bc5f-d2d3c866a151"}, {"dow": 2, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "b6e6f46d-a407-42c0-a184-5c4d5b18b746"}, {"dow": 2, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "3e0e8fc2-b3d9-4af5-bbcd-716813728f87"}, {"dow": 2, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 2, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 2, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "7891a809-607e-45b7-8e39-4151c9571713"}, {"dow": 2, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "434dbeb2-743b-47d5-a54d-ced650218678"}, {"dow": 3, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "3eb94f78-0164-42fc-9f81-64e77705050e"}, {"dow": 3, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "328addb1-94ad-4386-90fb-a09a546a3ca3"}, {"dow": 3, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 2, "recipe_id": "ce5e7dec-aebf-478c-9318-b5bdefe3eec4"}, {"dow": 3, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6"}, {"dow": 3, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 3, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "b49842f8-23b8-44bd-896d-a8e4dee42e39"}, {"dow": 3, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 3, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 4, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "ba6162e3-4267-4312-b0d9-f2b9a4f0a191"}, {"dow": 4, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 4, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "8d1ccede-f5e5-484c-a8bf-a849646d916d"}, {"dow": 4, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 4, "meal": "des", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "b49842f8-23b8-44bd-896d-a8e4dee42e39"}, {"dow": 4, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "434dbeb2-743b-47d5-a54d-ced650218678"}, {"dow": 4, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 4, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 1, "recipe_id": "44d2391a-55b3-4fff-8161-57faf0b189f7"}, {"dow": 5, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "49fff483-3a00-4611-addf-7028e500a5cc"}, {"dow": 5, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "163d1a0c-1573-4334-bad9-92078e5cbdc8"}, {"dow": 5, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "ce5e7dec-aebf-478c-9318-b5bdefe3eec4"}, {"dow": 5, "meal": "des", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "b49842f8-23b8-44bd-896d-a8e4dee42e39"}, {"dow": 5, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 5, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "ce5e7dec-aebf-478c-9318-b5bdefe3eec4"}, {"dow": 6, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "9c4bea69-06f9-40fd-b130-a5c7dfcf1a89"}, {"dow": 6, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 6, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "4b7ceedb-3445-48f5-8e2a-3a18893081fe"}, {"dow": 6, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 6, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 6, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 6, "meal": "mm", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}]	2026-11-22 15:11:50.480648+00	2026-11-22 15:11:50.480648+00
6ce5861b-ff8e-4fde-8aa2-009a982c316a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Menú 2	[{"dow": 0, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "3c873515-bfa4-41ac-97de-7ba908a8e4a7"}, {"dow": 0, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "7b820557-5377-4c59-a56b-ad58703ab091"}, {"dow": 0, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 2, "recipe_id": "b6e6f46d-a407-42c0-a184-5c4d5b18b746"}, {"dow": 0, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "9d5e5174-db78-4ad7-909f-8642d6c84a7d"}, {"dow": 0, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 0, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 0, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 0, "meal": "mm", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "7891a809-607e-45b7-8e39-4151c9571713"}, {"dow": 0, "meal": "mm", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "44d2391a-55b3-4fff-8161-57faf0b189f7"}, {"dow": 1, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "4f79bc5d-4f62-474b-bc9e-fc731584dfce"}, {"dow": 1, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "14fecc26-bc6f-4056-9da6-37e479d46d3b"}, {"dow": 1, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 1, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 1, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 1, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 2, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 2, "recipe_id": "d3afbd1e-ef86-4e18-9287-91367876235a"}, {"dow": 2, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 3, "recipe_id": "ce5e7dec-aebf-478c-9318-b5bdefe3eec4"}, {"dow": 2, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "3e0e8fc2-b3d9-4af5-bbcd-716813728f87"}, {"dow": 2, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 2, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 2, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "7891a809-607e-45b7-8e39-4151c9571713"}, {"dow": 2, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "434dbeb2-743b-47d5-a54d-ced650218678"}, {"dow": 3, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "8a0c6535-fd4a-4918-bc5f-d2d3c866a151"}, {"dow": 3, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "ce5e7dec-aebf-478c-9318-b5bdefe3eec4"}, {"dow": 3, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6"}, {"dow": 3, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 3, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "b49842f8-23b8-44bd-896d-a8e4dee42e39"}, {"dow": 3, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 3, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "cd348be5-c20d-4254-99cf-758c0911e060"}, {"dow": 4, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "ba6162e3-4267-4312-b0d9-f2b9a4f0a191"}, {"dow": 4, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 4, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "8d1ccede-f5e5-484c-a8bf-a849646d916d"}, {"dow": 4, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 4, "meal": "des", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "b49842f8-23b8-44bd-896d-a8e4dee42e39"}, {"dow": 4, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "434dbeb2-743b-47d5-a54d-ced650218678"}, {"dow": 4, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 4, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 1, "recipe_id": "44d2391a-55b3-4fff-8161-57faf0b189f7"}, {"dow": 5, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 2, "recipe_id": "3f6e65ea-66a6-421d-9ea7-6bd118219d40"}, {"dow": 5, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "163d1a0c-1573-4334-bad9-92078e5cbdc8"}, {"dow": 5, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "ce5e7dec-aebf-478c-9318-b5bdefe3eec4"}, {"dow": 5, "meal": "des", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "b49842f8-23b8-44bd-896d-a8e4dee42e39"}, {"dow": 5, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}, {"dow": 5, "meal": "mm", "label": null, "eat_out": null, "portions": {"0a416451-d5e0-479a-81d5-94da06c63548": 1, "bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca": 1, "c525a08d-787a-4cb9-b7a8-548a140ce0f2": 0, "d6d9d46b-1895-470d-85d2-413cf70e83a9": 0}, "position": 0, "recipe_id": "ce5e7dec-aebf-478c-9318-b5bdefe3eec4"}, {"dow": 6, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "9c4bea69-06f9-40fd-b130-a5c7dfcf1a89"}, {"dow": 6, "meal": "cen", "label": null, "eat_out": null, "portions": {}, "position": 1, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 6, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 2, "recipe_id": "a2cbaa67-6ca0-4758-8f34-dab33fd25c21"}, {"dow": 6, "meal": "com", "label": null, "eat_out": null, "portions": {}, "position": 3, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 6, "meal": "des", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "89bb2ccc-7818-4507-9334-73ab0a850fe6"}, {"dow": 6, "meal": "mer", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "a0015d7d-1c23-42ad-b98d-bb3e1596451f"}, {"dow": 6, "meal": "mm", "label": null, "eat_out": null, "portions": {}, "position": 0, "recipe_id": "77a3a5d9-8564-4d04-9bda-e70169882025"}]	2026-11-22 15:31:29.283059+00	2026-11-22 15:31:29.283059+00
\.


--
-- Data for Name: pantry_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pantry_items (id, household_id, name, place, qty, unit, recipe_id, expires_on, updated_at, added_on) FROM stdin;
56a870d5-e21a-4423-af66-bc87446a3581	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Lentejas	Nevera	8.00	raciones	8d1ccede-f5e5-484c-a8bf-a849646d916d	\N	2026-11-22 14:12:50.011987+00	2026-11-22
5c317f88-7bee-4332-96b7-6b58fbd0df7d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Agua	Despensa	4.00	ud	\N	\N	2026-11-22 14:28:52.209612+00	2026-11-22
\.


--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipe_ingredients (id, household_id, recipe_id, food_ref, name, grams, "position") FROM stdin;
3590acec-2052-436b-8395-23dc720a44aa	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	163d1a0c-1573-4334-bad9-92078e5cbdc8	bedca:980	Pollo	800.0	0
8244c70c-5582-4870-b664-abad184cfa9d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	163d1a0c-1573-4334-bad9-92078e5cbdc8	bedca:2402	Patata	400.0	1
cf19b6a2-704a-4ae1-8de8-c627e93ce508	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	ce5e7dec-aebf-478c-9318-b5bdefe3eec4	bedca:2235	Naranja	100.0	0
bf396450-93f5-46fb-afa5-748538906cbb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4b7ceedb-3445-48f5-8e2a-3a18893081fe	bedca:2404	Patata	100.0	0
61d9f8e7-9566-486f-bea2-2f8b74909630	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4b7ceedb-3445-48f5-8e2a-3a18893081fe	bedca:991	Ternera	100.0	1
1f7a00fc-ab76-460a-aba1-63dd4e826481	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4b7ceedb-3445-48f5-8e2a-3a18893081fe	bedca:2193	Guisantes en conserva	100.0	2
0cb74556-f022-4389-b384-b96e3b1e018e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4b7ceedb-3445-48f5-8e2a-3a18893081fe	bedca:2544	Aceite de oliva virgen extra	100.0	3
e6d61c44-1a00-4832-97b6-0de35a4bd459	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4b7ceedb-3445-48f5-8e2a-3a18893081fe	bedca:2409	Pimiento rojo	100.0	4
c579fb70-5d08-4436-88d0-b9c7627911ad	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3e0e8fc2-b3d9-4af5-bbcd-716813728f87	bedca:1020	Garbanzos	280.0	0
b239164b-c5af-4c70-83c4-92ecf8d30833	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3e0e8fc2-b3d9-4af5-bbcd-716813728f87	bedca:1029	Ternera	240.0	1
976c83dc-02a3-453b-863b-bfd02d025a29	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3e0e8fc2-b3d9-4af5-bbcd-716813728f87	bedca:2403	Patata	320.0	2
2b75322a-cdfa-4190-8c45-da25a4d960a9	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3e0e8fc2-b3d9-4af5-bbcd-716813728f87	bedca:2424	Zanahoria	160.0	3
e2ba9bc8-cab0-4f85-bc60-2061023f5541	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3e0e8fc2-b3d9-4af5-bbcd-716813728f87	bedca:993	Pollo	100.0	4
cd9e892b-5727-4b7a-8b69-5eecd3fa7bb2	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	e5fd29d2-3adb-441d-83c8-ca9ff72300d4	bedca:2661	Arroz	100.0	0
e76a8265-e9ba-4ea8-a203-f2c4ac04aa9d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	e5fd29d2-3adb-441d-83c8-ca9ff72300d4	bedca:759	Huevo de gallina	400.0	1
51cdbfdc-efcb-4840-96e9-c96318f94f7a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	e5fd29d2-3adb-441d-83c8-ca9ff72300d4	bedca:2560	Tomate frito	100.0	2
256de047-d87c-4ab7-8a53-87c02f1f14bd	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d3afbd1e-ef86-4e18-9287-91367876235a	bedca:2680	Carne picada	800.0	0
bac85ba4-6556-4e27-950f-bc75690f26c3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d3afbd1e-ef86-4e18-9287-91367876235a	bedca:2424	Zanahoria	300.0	1
7b40da9e-ea35-4ef4-8a13-1bae24ca2403	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d3afbd1e-ef86-4e18-9287-91367876235a	bedca:2381	Cebolla	300.0	2
917f99bc-b0b8-476d-aebc-759274bb12d3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	89bb2ccc-7818-4507-9334-73ab0a850fe6	bedca:2165	Pan blanco	200.0	0
e5a9c01d-1f20-4d98-9224-64ad9db95ba3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	89bb2ccc-7818-4507-9334-73ab0a850fe6	bedca:2543	Aceite de oliva	50.0	1
3cdc40ef-f1cc-4a4f-a1e2-9e1630050f3d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	89bb2ccc-7818-4507-9334-73ab0a850fe6	bedca:2273	Jamón serrano	50.0	2
686be4b5-3e08-485e-affe-122b3016ea6c	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	ba6162e3-4267-4312-b0d9-f2b9a4f0a191	bedca:2127	Huevos	400.0	0
d9c749f5-4fc3-4745-952c-48801a3491fb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	ba6162e3-4267-4312-b0d9-f2b9a4f0a191	bedca:2403	Patata	480.0	1
f82e29d7-15a3-4a81-a4fa-195a31d07992	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	ba6162e3-4267-4312-b0d9-f2b9a4f0a191	bedca:2381	Cebolla	120.0	2
5aa537c8-1c1e-4f20-a59d-1015d4816508	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	ba6162e3-4267-4312-b0d9-f2b9a4f0a191	bedca:2544	Aceite de oliva virgen extra	60.0	3
68a6bf29-3bd3-4483-8747-b15df6961e55	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3c873515-bfa4-41ac-97de-7ba908a8e4a7	bedca:2565	Sopa de sobre maravilla	400.0	0
10fff70a-518a-49e0-903d-b30292c1e720	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	328addb1-94ad-4386-90fb-a09a546a3ca3	bedca:2626	Salmón	400.0	0
91e77cf1-c30c-49dc-8604-bf7fd3edb138	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8d1ccede-f5e5-484c-a8bf-a849646d916d	bedca:1065	Lentejas	280.0	0
254d65f2-3e86-4df5-93fc-16f30598862a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8d1ccede-f5e5-484c-a8bf-a849646d916d	bedca:2403	Patata	240.0	1
3970df7f-2d77-430d-876e-69f7b006e50e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8d1ccede-f5e5-484c-a8bf-a849646d916d	bedca:2424	Zanahoria	160.0	2
f59053ce-8875-40df-920a-4bbf09271ade	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8d1ccede-f5e5-484c-a8bf-a849646d916d	bedca:2381	Cebolla	120.0	3
6dc45da5-482c-409c-98a3-e76e38c5e891	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8d1ccede-f5e5-484c-a8bf-a849646d916d	bedca:2409	Pimiento	80.0	4
5fc07627-ca23-4249-902e-3babbfc2c1df	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8d1ccede-f5e5-484c-a8bf-a849646d916d	bedca:2544	Aceite de oliva virgen extra	32.0	5
9a1572a3-625e-48f3-9525-aebf4ec7442d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	44d2391a-55b3-4fff-8161-57faf0b189f7	bedca:2493	Leche de vaca	250.0	0
78b1847c-8725-4d3b-b8ec-82a721436f72	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3eb94f78-0164-42fc-9f81-64e77705050e	bedca:2363	Alcachofas en conserva	400.0	0
1d17ba8f-d954-454a-a0c0-2ffeff4e3ccf	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3eb94f78-0164-42fc-9f81-64e77705050e	bedca:2129	Anchoas en aceite vegetal	100.0	1
1ceeba53-6307-47b7-9e80-e9252e778cdf	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3eb94f78-0164-42fc-9f81-64e77705050e	bedca:2543	Aceite de oliva	100.0	2
d6b5ddf8-9994-4483-a6e2-645d32ee88c6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6	bedca:2660	Arroz	100.0	0
bf018b14-65c9-4b6e-a74b-fd7606027c79	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6	bedca:2295	Pollo	100.0	1
e35be5f7-a0c9-4bce-a777-69dcfb99bacb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6	bedca:2409	Pimiento rojo	100.0	2
cb43c37d-7239-42ee-948a-4e26270ee808	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6	bedca:2381	Cebolla	100.0	3
6ab24d24-85ca-4d33-b047-ef760aab7f08	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	cd348be5-c20d-4254-99cf-758c0911e060	bedca:2163	Pan integral	100.0	0
2e086314-f296-4125-8bf3-992638ccf753	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	cd348be5-c20d-4254-99cf-758c0911e060	bedca:2273	Jamón serrano	100.0	1
936a36db-728d-4574-acde-31aac82f1345	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	434dbeb2-743b-47d5-a54d-ced650218678	bedca:2163	Pan integral	200.0	0
05f12187-d96b-4c3c-ab3f-cae1be04fd6b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	434dbeb2-743b-47d5-a54d-ced650218678	bedca:2293	Pollo	100.0	1
11b8b27c-21b0-48c4-b299-dbddd7342c6e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	b1da65b2-2f9c-452d-b9e2-38812c6be002	bedca:681	Café	250.0	0
693cc360-b5f5-4874-96ac-29e2d46d1c05	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8a0c6535-fd4a-4918-bc5f-d2d3c866a151	bedca:2387	Coliflor	800.0	0
8deb0960-adc6-4c46-a7c7-361958e8e269	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8a0c6535-fd4a-4918-bc5f-d2d3c866a151	bedca:2319	Caballa	200.0	1
604a6cca-7ef2-42f4-b9fe-72c2dca5f234	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8a0c6535-fd4a-4918-bc5f-d2d3c866a151	bedca:2512	Queso parmesano	100.0	2
3b51457d-c9c7-44a8-9028-ff4e9983efec	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8a0c6535-fd4a-4918-bc5f-d2d3c866a151	bedca:2543	Aceite de oliva	100.0	3
8d8951f3-fa8e-41ae-a448-b8291cb75757	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	8a0c6535-fd4a-4918-bc5f-d2d3c866a151	bedca:2592	Pimentón	100.0	4
e5cb83bc-4ef5-46e2-9fe2-48bfdc77daf5	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	14fecc26-bc6f-4056-9da6-37e479d46d3b	bedca:1076	Pasta alimenticia	400.0	0
89419279-bd34-4f24-98c3-77af863cec7b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	14fecc26-bc6f-4056-9da6-37e479d46d3b	bedca:2127	Huevo de gallina fresco	600.0	1
95bbffb7-afa3-4a1c-a969-62e86f1d4cbb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	14fecc26-bc6f-4056-9da6-37e479d46d3b	bedca:2512	Queso parmesano	100.0	2
0c5c9fba-30a5-4c97-8f2a-7c1e08418787	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	14fecc26-bc6f-4056-9da6-37e479d46d3b	bedca:2543	Aceite de oliva	80.0	3
762510e5-0249-464d-9cd0-398587ad98e8	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	14fecc26-bc6f-4056-9da6-37e479d46d3b	bedca:805	Caballa	200.0	4
12dda015-1208-4626-8dd7-84a7b72d568e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	77a3a5d9-8564-4d04-9bda-e70169882025	bedca:2229	Mandarina	100.0	0
4433a619-84bf-47d2-8bd4-58348505e76c	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	b49842f8-23b8-44bd-896d-a8e4dee42e39	bedca:2493	Leche de vaca	200.0	0
b15b7b0e-a939-4aac-bd68-b311c06ffe3e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	b49842f8-23b8-44bd-896d-a8e4dee42e39	bedca:1010	Avena	60.0	1
8ae45163-a398-4c64-ba1c-12fd8000d198	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	7b820557-5377-4c59-a56b-ad58703ab091	bedca:2259	Cerdo	400.0	0
724896e6-ac01-4f81-a2e6-2580edd2009b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	7b820557-5377-4c59-a56b-ad58703ab091	bedca:2543	Aceite de oliva	60.0	1
6556dffa-da8f-44a2-ad14-39aa8a20b176	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	7891a809-607e-45b7-8e39-4151c9571713	bedca:2245	Plátano	100.0	0
85fd2dc1-bfe7-40e5-92a8-c37765628634	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	b6e6f46d-a407-42c0-a184-5c4d5b18b746	bedca:2249	Uva blanca	100.0	0
8edce598-9b55-4c61-8766-9c55638b2972	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d3afbd1e-ef86-4e18-9287-91367876235a	bedca:2544	Aceite de oliva virgen extra	100.0	3
5debace5-1e95-43a7-be2a-5ae9cfa33621	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	d3afbd1e-ef86-4e18-9287-91367876235a	bedca:2605	Ketchup	100.0	4
86cf23c6-1ea6-47f7-ac42-de3d102b29e6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:2660	Arroz	400.0	0
a2f0de82-f9c7-49c2-ad3e-56a4da2840db	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:807	Calamar	300.0	1
0cf68ce3-487f-4f6b-a6d2-c1cc5be3a50e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:816	Gamba quisquilla	200.0	2
33952d2e-4da4-48be-b7cb-8e0c1429d3fe	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:2361	Ajo	30.0	3
5f74525d-215e-4d2e-a189-7027e5660122	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:2381	Cebolla	200.0	4
68e3a2c1-387f-4745-b207-4bb7bea51828	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:2409	Pimiento rojo	100.0	5
02667c65-8a6d-40be-b007-8628605fd559	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:2475	Azafrán	3.0	6
c45a54cf-d989-46e7-813e-e6929ddb0dcf	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a4da4ac6-1d99-4520-a214-9f6d311e293a	bedca:2592	Pimentón	100.0	7
45f6bc18-b1c2-4724-8038-ec6afed715e2	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	11744614-9439-4293-98cd-54bd53d20869	bedca:1074	Pasta alimenticia	100.0	0
64735828-4be7-42d6-8e85-233943b133da	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	11744614-9439-4293-98cd-54bd53d20869	bedca:2361	Ajo	100.0	1
fa5c6727-b24c-4ec4-a0da-ab0ae64ea40a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	11744614-9439-4293-98cd-54bd53d20869	bedca:2560	Tomate frito	100.0	2
bc7a47a6-57de-4e16-b63d-85468f731e1e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	11744614-9439-4293-98cd-54bd53d20869	bedca:2680	Carne picada	100.0	3
d2484f0f-3870-4df2-8d7f-ff375df3b7c5	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	11744614-9439-4293-98cd-54bd53d20869	bedca:2544	Aceite de oliva virgen extra	100.0	4
af7c59d2-ef10-4401-bdea-83d41548f85b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a2cbaa67-6ca0-4758-8f34-dab33fd25c21	bedca:2127	Huevo de gallina fresco	300.0	0
fcb4a528-0705-4d7e-b7de-5014977e464e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a2cbaa67-6ca0-4758-8f34-dab33fd25c21	bedca:2409	Pimiento rojo	300.0	1
4ec5ca29-4831-48ad-80a3-f99c0b75cc77	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a2cbaa67-6ca0-4758-8f34-dab33fd25c21	bedca:2403	Patata	400.0	2
a1f4f16a-f1cb-4074-a1af-96b320d50693	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4f79bc5d-4f62-474b-bc9e-fc731584dfce	bedca:1060	Masa de hojaldre	100.0	0
c563ad92-daaa-4b27-8941-029ed8e97826	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4f79bc5d-4f62-474b-bc9e-fc731584dfce	bedca:2560	Tomate frito	100.0	1
05865a28-fe99-4e6c-8e9b-00b82b11318d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4f79bc5d-4f62-474b-bc9e-fc731584dfce	bedca:2381	Cebolla	100.0	2
8680cd03-1cd1-4c1e-97a1-b7087f8dfc03	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4f79bc5d-4f62-474b-bc9e-fc731584dfce	bedca:2510	Queso mozzarella	100.0	3
095f054a-8576-45c6-9ed6-710c9e08edfc	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4f79bc5d-4f62-474b-bc9e-fc731584dfce	bedca:2698	Carne de cerdo de capa blanca	100.0	4
1c310a54-4363-4505-b582-fa9c3c557542	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	4f79bc5d-4f62-474b-bc9e-fc731584dfce	bedca:2134	Atún	100.0	5
2647ca2f-a1a2-49dc-a863-e652b7fc5e9d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	a0015d7d-1c23-42ad-b98d-bb3e1596451f	bedca:2213	Caqui	100.0	0
f4ffa9dc-8119-4a85-af4f-42f52708285e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	e6108671-8cd3-497a-ad92-8efd5b2af6f3	bedca:2297	Pollo	600.0	0
8bf3d12c-4eb6-4c86-800f-b43cd46affcb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	e6108671-8cd3-497a-ad92-8efd5b2af6f3	bedca:2409	Pimiento rojo	300.0	1
22ad5e66-e60f-4326-a0fa-e4f82a82a0ad	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	e6108671-8cd3-497a-ad92-8efd5b2af6f3	bedca:2381	Cebolla	100.0	2
f88f09fb-d94c-484e-ad32-09c6f00cfaba	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3f6e65ea-66a6-421d-9ea7-6bd118219d40	bedca:718	Queso Mahón	100.0	0
f9f900d8-455b-40b0-a406-2c9a2e00a505	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3f6e65ea-66a6-421d-9ea7-6bd118219d40	bedca:2214	Aceituna	100.0	1
fd1c0fa6-fb79-4d14-83c8-9670aa72c23d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3f6e65ea-66a6-421d-9ea7-6bd118219d40	bedca:2306	Berberechos	100.0	2
070b01ad-d68d-4e96-a47c-327d726c9e53	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3f6e65ea-66a6-421d-9ea7-6bd118219d40	bedca:1124	Soja	100.0	3
e6e71a8a-f4ab-4ff7-9ef4-488b8ce4c3fc	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3f6e65ea-66a6-421d-9ea7-6bd118219d40	bedca:1777	Jamón ibérico de cebo	100.0	4
8476901f-9ff2-42ce-b984-46bc9cd9c42b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	3f6e65ea-66a6-421d-9ea7-6bd118219d40	bedca:2406	Pepinillos en vinagre	100.0	5
236baaf7-f227-4577-a03b-e277daab1eed	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	bedca:2399	Lechuga	100.0	0
0df42a70-91b7-4bd8-b0ac-37e6865423fe	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	bedca:805	Caballa	100.0	1
ffa14518-9a30-454f-9f61-8e382cfffdca	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	bedca:2421	Tomate	100.0	2
7e023511-605e-4adc-bb21-43e64051770a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	bedca:2543	Aceite de oliva	100.0	3
a44b7b88-4e19-4d4e-8a3c-faf566882c7a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	bedca:2512	Queso parmesano	100.0	4
65a68986-0d1e-4bcc-8359-4b486b26e059	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	bedca:2127	Huevo de gallina fresco	240.0	5
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipes (id, household_id, name, kind, food_id, servings, minutes, meals, groups, steps, updated_at, icon, note, kid_friendly, portion_g, pack_portions, suggested_key) FROM stdin;
8a0c6535-fd4a-4918-bc5f-d2d3c866a151	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Colifror	receta	\N	4.0	\N	{com,cen}	{verdura,lacteo,pescado}	\N	2026-11-22 10:24:35.328075+00	🍲	\N	t	\N	\N	\N
89bb2ccc-7818-4507-9334-73ab0a850fe6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Tostada con aceite y jamón	receta	\N	2.0	\N	{com,cen}	{}	\N	2026-11-21 20:59:41.091148+00	🍞	\N	t	\N	\N	\N
ba6162e3-4267-4312-b0d9-f2b9a4f0a191	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Tortilla de patatas	receta	\N	4.0	40	{cen,com}	{huevo,verdura}	Confita patata y cebolla en poco aceite.\nMezcla con el huevo batido y cuaja.	2026-11-22 08:06:49.678032+00	🍳	\N	t	\N	\N	tortilla
3c873515-bfa4-41ac-97de-7ba908a8e4a7	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Sopa	receta	\N	4.0	\N	{com,cen}	{}	\N	2026-11-22 08:10:42.413789+00	🍽️	\N	t	\N	\N	\N
328addb1-94ad-4386-90fb-a09a546a3ca3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Salmón plancha	receta	\N	4.0	\N	{com,cen}	{}	\N	2026-11-22 08:13:30.959258+00	🐟	\N	t	\N	\N	\N
8d1ccede-f5e5-484c-a8bf-a849646d916d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Lentejas	receta	\N	4.0	45	{com,cen}	{legumbre,verdura}	Sofríe cebolla, pimiento y zanahoria.\nAñade lentejas, patata y agua; cuece 35 min a fuego medio.	2026-11-22 08:14:02.990559+00	🍲	\N	t	\N	\N	lentejas
4b7ceedb-3445-48f5-8e2a-3a18893081fe	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Estofado de ternera	receta	\N	4.0	\N	{com,cen}	{verdura,roja}	\N	2026-11-22 10:35:06.33284+00	🥘	\N	t	\N	\N	\N
14fecc26-bc6f-4056-9da6-37e479d46d3b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Ensalada de pasta	receta	\N	4.0	\N	{com,cen}	{huevo,lacteo,pescado,verdura}	\N	2026-11-22 10:25:04.281715+00	🍛	\N	t	\N	\N	\N
44d2391a-55b3-4fff-8161-57faf0b189f7	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Vaso de leche entera	receta	\N	4.0	\N	{com,cen}	{}	\N	2026-11-22 10:16:01.546951+00	🥛	\N	t	\N	\N	\N
9d5e5174-db78-4ad7-909f-8642d6c84a7d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Ensalada judías blancas	receta	\N	4.0	\N	{com,cen}	{legumbre,verdura,pescado,huevo}	\N	2026-11-22 10:25:18.919449+00	🥗	\N	t	\N	\N	\N
3eb94f78-0164-42fc-9f81-64e77705050e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Alcachofas con anchoas	receta	\N	4.0	\N	{com,cen}	{verdura}	\N	2026-11-22 10:23:00.982673+00	🥦	\N	t	\N	\N	\N
d5b1b3df-18e0-4426-b545-0e8e4e4fe2d6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Arroz con pollo	receta	\N	4.0	\N	{com,cen}	{verdura,blanca}	\N	2026-11-22 10:23:24.315441+00	🥘	\N	t	\N	\N	\N
cd348be5-c20d-4254-99cf-758c0911e060	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Bocadillo jamón	receta	\N	4.0	\N	{mm,mer}	{blanca}	\N	2026-11-22 10:23:43.799738+00	🥪	\N	t	\N	\N	\N
434dbeb2-743b-47d5-a54d-ced650218678	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Bocadillo pollo	receta	\N	2.0	\N	{mm,mer}	{blanca}	\N	2026-11-22 10:23:53.63798+00	🥪	\N	t	\N	\N	\N
b1da65b2-2f9c-452d-b9e2-38812c6be002	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Café con leche	receta	\N	2.0	\N	{des,mm,mer}	{lacteo}	\N	2026-11-22 10:24:04.784208+00	🥛	\N	f	\N	\N	\N
e6108671-8cd3-497a-ad92-8efd5b2af6f3	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Fajitas	receta	\N	4.0	\N	{com,cen}	{verdura,blanca}	\N	2026-11-22 15:18:58.433831+00	🌯	\N	t	\N	\N	\N
77a3a5d9-8564-4d04-9bda-e70169882025	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Mandarina	receta	\N	4.0	\N	{com,cen}	{fruta}	\N	2026-11-22 10:25:25.381756+00	🍎	\N	t	\N	\N	\N
3e0e8fc2-b3d9-4af5-bbcd-716813728f87	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Cocido	receta	\N	4.0	150	{com}	{legumbre,verdura,blanca}	Remoja los garbanzos la noche antes.\nCuece carne y garbanzos 2 h; añade verdura y patata la última media hora.	2026-11-22 10:35:55.399584+00	🍲	\N	t	\N	\N	cocido
b49842f8-23b8-44bd-896d-a8e4dee42e39	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Leche con avena	receta	\N	4.0	\N	{des}	{lacteo}	\N	2026-11-22 10:25:42.841529+00	🥛	\N	t	\N	\N	\N
49fff483-3a00-4611-addf-7028e500a5cc	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Hamburguesa	receta	\N	4.0	\N	{com,cen}	{roja,lacteo}	\N	2026-11-22 10:25:57.531733+00	🍔	\N	t	\N	\N	\N
7b820557-5377-4c59-a56b-ad58703ab091	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Filetes de lomo	receta	\N	4.0	\N	{com,cen}	{blanca}	\N	2026-11-22 10:26:05.730838+00	🥩	\N	t	\N	\N	\N
3f6e65ea-66a6-421d-9ea7-6bd118219d40	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Tapillas	receta	\N	4.0	\N	{cen}	{}	\N	2026-11-22 15:28:10.354951+00	🥟	\N	t	\N	\N	\N
7891a809-607e-45b7-8e39-4151c9571713	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Plátano	receta	\N	4.0	\N	{mm,mer}	{fruta}	\N	2026-11-22 10:26:18.685294+00	🍌	\N	t	\N	\N	\N
b6e6f46d-a407-42c0-a184-5c4d5b18b746	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Uvas	receta	\N	4.0	\N	{com,cen,mm,mer}	{fruta}	\N	2026-11-22 10:26:23.439351+00	🍎	\N	t	\N	\N	\N
163d1a0c-1573-4334-bad9-92078e5cbdc8	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pollo asado	receta	\N	4.0	\N	{com,cen}	{verdura,blanca}	\N	2026-11-22 10:33:00.277258+00	🍗	\N	t	\N	\N	\N
ce5e7dec-aebf-478c-9318-b5bdefe3eec4	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Naranjas	receta	\N	4.0	\N	{com,cen}	{}	\N	2026-11-22 10:34:09.125609+00	🍎	\N	t	\N	\N	\N
e5fd29d2-3adb-441d-83c8-ca9ff72300d4	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Arroz a la cubana	receta	\N	4.0	\N	{com,cen}	{huevo}	\N	2026-11-22 10:37:28.009696+00	🍚	\N	t	\N	\N	\N
d3afbd1e-ef86-4e18-9287-91367876235a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Burritos	receta	\N	4.0	\N	{com,cen}	{roja}	\N	2026-11-22 14:12:07.017277+00	🌯	\N	t	\N	\N	\N
a4da4ac6-1d99-4520-a214-9f6d311e293a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Arroz negro	receta	\N	4.0	\N	{com}	{pescado}	\N	2026-11-22 14:21:12.227836+00	🍚	\N	t	\N	\N	\N
11744614-9439-4293-98cd-54bd53d20869	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Espaguetis	receta	\N	4.0	\N	{com,cen}	{}	\N	2026-11-22 14:27:02.915254+00	🍲	\N	t	\N	\N	\N
a2cbaa67-6ca0-4758-8f34-dab33fd25c21	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Huevos, patatas, pimientos	receta	\N	4.0	\N	{com,cen}	{huevo,verdura}	\N	2026-11-22 14:35:32.441265+00	🍳	\N	t	\N	\N	\N
d20411fc-3f5c-43b4-9428-88f941c100d5	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Ensaladilla rusa	receta	\N	4.0	\N	{com,cen}	{}	\N	2026-11-22 14:37:11.484586+00	🥗	\N	t	\N	\N	\N
4f79bc5d-4f62-474b-bc9e-fc731584dfce	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pizza	receta	\N	4.0	\N	{com,cen}	{}	\N	2026-11-22 14:50:58.715775+00	🍕	\N	t	\N	\N	\N
a0015d7d-1c23-42ad-b98d-bb3e1596451f	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pérsimon	receta	\N	4.0	\N	{com,cen}	{fruta}	\N	2026-11-22 15:10:29.558656+00	🍎	\N	t	\N	\N	\N
9c4bea69-06f9-40fd-b130-a5c7dfcf1a89	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Ensalada	receta	\N	4.0	\N	{com,cen}	{verdura,lacteo,huevo}	\N	2026-11-22 15:33:07.277181+00	🥗	\N	t	\N	\N	\N
\.


--
-- Data for Name: saved_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_products (id, household_id, name, section) FROM stdin;
9e2a1d7f-f2a2-4375-a062-0f256bcdc7c2	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pulpo	Carne y pescado
\.


--
-- Data for Name: shopping_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shopping_items (id, household_id, name, section, qty, unit, checked, updated_at, from_menu, note, created_at) FROM stdin;
eab227a8-9af4-4def-87fb-e53914ce13b4	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Cebolla	Fruta y verdura	300.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Arroz con pollo, Tortilla de patatas, Lentejas	2026-11-22 14:28:04.871556+00
0db59876-1668-467b-88e1-6e40ca00b4eb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Coliflor	Fruta y verdura	650.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Colifror	2026-11-22 14:28:04.871556+00
da5d475e-225e-4360-a839-6814426e82cf	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Lechuga	Fruta y verdura	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Ensalada	2026-11-22 14:28:04.871556+00
550eb7d7-f42b-44ae-b222-9c68ed3c0fc0	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Mandarina	Fruta y verdura	800.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Mandarina	2026-11-22 14:28:04.871556+00
40d9e110-17fb-4da3-9d56-06880ea20c89	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Naranja	Fruta y verdura	350.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Naranjas	2026-11-22 14:28:04.871556+00
0172f10b-880b-4592-9c15-580953b48f1b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Patata	Fruta y verdura	1000.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Tortilla de patatas, Lentejas, Cocido	2026-11-22 14:28:04.871556+00
d744b1b3-e584-42e3-88b6-d231308cd3bc	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Patata	Fruta y verdura	350.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Pollo asado	2026-11-22 14:28:04.871556+00
ae100e7c-7c48-48c0-a4c1-ceb4228d4504	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Patata	Fruta y verdura	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Estofado de ternera	2026-11-22 14:28:04.871556+00
6ac4923a-bc56-4537-bebb-5b8fd51acbad	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pimiento rojo	Fruta y verdura	300.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Arroz con pollo, Estofado de ternera, Lentejas	2026-11-22 14:28:04.871556+00
a1ddfbbb-533a-4b3d-b576-321bdd5f2bfe	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Plátano	Fruta y verdura	250.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Plátano	2026-11-22 14:28:04.871556+00
3aa4c6ed-d926-4c7a-bccc-0bc9a83c36c6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Tomate	Fruta y verdura	90.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Ensalada	2026-11-22 14:28:04.871556+00
f04e250e-5643-4b8f-bfde-c0f635aebf1e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Uva blanca	Fruta y verdura	200.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Uvas	2026-11-22 14:28:04.871556+00
2cd7bd3a-968f-410a-a7f3-67315315db25	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Zanahoria	Fruta y verdura	250.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Lentejas, Cocido	2026-11-22 14:28:04.871556+00
cfe3fe0a-578d-46dc-802c-79765b382389	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Cerdo	Carne y pescado	350.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Filetes de lomo	2026-11-22 14:28:04.871556+00
8656e360-8860-4dab-9ae0-b4470f239c31	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Jamón serrano	Carne y pescado	650.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Tostada con aceite y jamón, Bocadillo jamón	2026-11-22 14:28:04.871556+00
cfe841cc-6d4d-407a-8e98-3cac05c7a9a1	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pollo	Carne y pescado	350.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Bocadillo pollo	2026-11-22 14:28:04.871556+00
4da4a36b-a47c-4fd5-8e24-21875c44248d	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pollo	Carne y pescado	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Arroz con pollo	2026-11-22 14:28:04.871556+00
b22fdfe5-74c2-45f2-9232-a38f2b36c564	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pollo	Carne y pescado	650.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Pollo asado	2026-11-22 14:28:04.871556+00
0aed5afe-94c3-422d-9773-e1a3e8b56aed	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pollo	Carne y pescado	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Cocido	2026-11-22 14:28:04.871556+00
944e0daf-b8ae-4b64-b02a-c8b5b16ec818	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Salmón	Carne y pescado	500.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Salmón plancha	2026-11-22 14:28:04.871556+00
d8e13908-707d-4e22-922e-8e67d0f88373	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Ternera	Carne y pescado	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Estofado de ternera	2026-11-22 14:28:04.871556+00
80bac20e-cb91-4750-90d1-fab125f719a6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Ternera	Carne y pescado	200.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Cocido	2026-11-22 14:28:04.871556+00
9a40f899-27c0-45a3-8925-81bf398b9406	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Avena	Lácteos y huevos	150.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Leche con avena	2026-11-22 14:28:04.871556+00
f6ee271b-20e3-463c-b658-ac0a9ddd7520	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Huevos	Lácteos y huevos	16.00	ud	f	2026-11-22 14:28:04.871556+00	t	Para Tortilla de patatas, Ensalada de pasta	2026-11-22 14:28:04.871556+00
4c20e36e-7c6e-4e76-9228-9c6c44ee521f	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Queso parmesano	Lácteos y huevos	250.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Colifror, Ensalada, Ensalada de pasta	2026-11-22 14:28:04.871556+00
de66eb01-9e38-4a46-9d3c-48e9519dc0a1	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pan integral	Panadería	950.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Bocadillo jamón, Bocadillo pollo	2026-11-22 14:28:04.871556+00
00dd7e81-4e17-4168-aac1-1d9d16a89d6b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Aceite de oliva	Despensa	700.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Tostada con aceite y jamón, Colifror, Alcachofas con anchoas, Ensalada, Filetes de lomo, Ensalada de pasta	2026-11-22 14:28:04.871556+00
9687906b-7f7c-4339-9382-08c2e4efb0ff	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Aceite de oliva virgen extra	Despensa	150.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Tortilla de patatas, Estofado de ternera, Lentejas	2026-11-22 14:28:04.871556+00
c1f116a6-9679-4bbb-9aad-614016a424dd	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Arroz	Despensa	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Arroz con pollo	2026-11-22 14:28:04.871556+00
cd894f29-dad2-4e9b-ad0c-d3ad89907c1b	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Garbanzos	Despensa	250.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Cocido	2026-11-22 14:28:04.871556+00
d22be7ad-4bb3-47d4-889e-854242f84960	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Lentejas	Despensa	250.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Lentejas	2026-11-22 14:28:04.871556+00
30952f9c-cd95-4c9d-a459-63858a8e5eaf	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pimentón	Despensa	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Colifror	2026-11-22 14:28:04.871556+00
bfa0df5f-5639-4590-8720-dbd9cf19cb06	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Alcachofas en conserva	Otros	350.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Alcachofas con anchoas	2026-11-22 14:28:04.871556+00
1400f54c-e781-4290-97d8-9dc95aff3a51	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Anchoas en aceite vegetal	Otros	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Alcachofas con anchoas	2026-11-22 14:28:04.871556+00
9bdc0fd1-63a0-40dc-b23d-f24a26e82e00	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Caballa	Otros	200.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Colifror	2026-11-22 14:28:04.871556+00
2b533f77-e1af-4db6-9e77-d465b95c984a	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Caballa	Otros	250.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Ensalada, Ensalada de pasta	2026-11-22 14:28:04.871556+00
c579e764-2db9-4cc3-b832-fa6e651641e8	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Caqui	Otros	600.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Persimón	2026-11-22 14:28:04.871556+00
1c9b3419-f9b1-4bfe-a1bb-84b50f964998	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Guisantes en conserva	Otros	80.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Estofado de ternera	2026-11-22 14:28:04.871556+00
a7a94b3d-dde5-41c4-b472-0af643dab5e9	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Leche de vaca	Otros	750.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Leche con avena, Vaso de leche entera	2026-11-22 14:28:04.871556+00
21ca4e5f-951e-4bbd-8729-babb633f9da6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pan blanco	Otros	1250.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Tostada con aceite y jamón	2026-11-22 14:28:04.871556+00
34b15770-777e-4665-82ce-1f2ff2160ea6	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Pasta alimenticia	Otros	350.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Ensalada de pasta	2026-11-22 14:28:04.871556+00
c35cb7b1-7152-4f07-bbb1-f8ea5f767849	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Sopa de sobre maravilla	Otros	350.00	g	f	2026-11-22 14:28:04.871556+00	t	Para Sopa	2026-11-22 14:28:04.871556+00
1d217800-5007-4c52-b863-5dce19aad47e	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Desodorante	Higiene personal	\N	\N	f	2026-11-22 14:28:17.641786+00	f	\N	2026-11-22 14:28:17.641786+00
a5cd2287-de03-48a1-adcd-5dd1e6615e93	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Gel de ducha	Higiene personal	\N	\N	f	2026-11-22 14:28:18.222153+00	f	\N	2026-11-22 14:28:18.222153+00
2ea898ad-b8aa-48e4-b6b8-b3ecd1b2e0cb	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Papel de cocina	Limpieza y hogar	\N	\N	f	2026-11-22 14:28:18.433995+00	f	\N	2026-11-22 14:28:18.433995+00
7727861a-9c7c-40d1-85c9-57fa88a67fcc	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Champú	Higiene personal	\N	\N	f	2026-11-22 14:28:19.002657+00	f	\N	2026-11-22 14:28:19.002657+00
3cd6143e-3bcf-4231-b087-beef199c2be1	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Detergente	Limpieza y hogar	\N	\N	f	2026-11-22 14:28:19.313445+00	f	\N	2026-11-22 14:28:19.313445+00
f826d3bc-ed96-4af5-a7d0-ae8eee829783	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Suavizante	Limpieza y hogar	\N	\N	f	2026-11-22 14:28:19.551018+00	f	\N	2026-11-22 14:28:19.551018+00
\.


--
-- Data for Name: weight_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weight_log (id, household_id, member_id, day, weight_kg, waist_cm) FROM stdin;
bbca93c0-bfe4-4cd4-95dc-abcbb86b7032	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	c525a08d-787a-4cb9-b7a8-548a140ce0f2	2026-11-21	74.00	\N
\.


--
-- Name: foods foods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_pkey PRIMARY KEY (id);


--
-- Name: household_users household_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_users
    ADD CONSTRAINT household_users_pkey PRIMARY KEY (household_id, user_id);


--
-- Name: households households_invite_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_invite_code_key UNIQUE (invite_code);


--
-- Name: households households_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_pkey PRIMARY KEY (id);


--
-- Name: meal_plan_items meal_plan_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: menu_templates menu_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_templates
    ADD CONSTRAINT menu_templates_pkey PRIMARY KEY (id);


--
-- Name: pantry_items pantry_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pantry_items
    ADD CONSTRAINT pantry_items_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: saved_products saved_products_household_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_products
    ADD CONSTRAINT saved_products_household_id_name_key UNIQUE (household_id, name);


--
-- Name: saved_products saved_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_products
    ADD CONSTRAINT saved_products_pkey PRIMARY KEY (id);


--
-- Name: shopping_items shopping_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_pkey PRIMARY KEY (id);


--
-- Name: weight_log weight_log_member_id_day_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_member_id_day_key UNIQUE (member_id, day);


--
-- Name: weight_log weight_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_pkey PRIMARY KEY (id);


--
-- Name: household_users_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX household_users_user_idx ON public.household_users USING btree (user_id);


--
-- Name: meal_plan_items_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meal_plan_items_day_idx ON public.meal_plan_items USING btree (household_id, day);


--
-- Name: menu_templates_household_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX menu_templates_household_idx ON public.menu_templates USING btree (household_id);


--
-- Name: recipe_ingredients_household_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recipe_ingredients_household_idx ON public.recipe_ingredients USING btree (household_id);


--
-- Name: recipe_ingredients_recipe_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recipe_ingredients_recipe_idx ON public.recipe_ingredients USING btree (recipe_id);


--
-- Name: recipes_suggested_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX recipes_suggested_key_idx ON public.recipes USING btree (household_id, suggested_key) WHERE (suggested_key IS NOT NULL);


--
-- Name: saved_products_household_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX saved_products_household_idx ON public.saved_products USING btree (household_id);


--
-- Name: shopping_items_household_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shopping_items_household_idx ON public.shopping_items USING btree (household_id);


--
-- Name: foods foods_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER foods_touch BEFORE UPDATE ON public.foods FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: meal_plan_items meal_plan_items_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER meal_plan_items_touch BEFORE UPDATE ON public.meal_plan_items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: members members_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER members_touch BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: menu_templates menu_templates_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER menu_templates_touch BEFORE UPDATE ON public.menu_templates FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: pantry_items pantry_items_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pantry_items_touch BEFORE UPDATE ON public.pantry_items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: recipes recipes_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recipes_touch BEFORE UPDATE ON public.recipes FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: shopping_items shopping_items_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER shopping_items_touch BEFORE UPDATE ON public.shopping_items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: foods foods_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: household_users household_users_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_users
    ADD CONSTRAINT household_users_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: household_users household_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_users
    ADD CONSTRAINT household_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: households households_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: meal_plan_items meal_plan_items_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: meal_plan_items meal_plan_items_pantry_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_pantry_item_id_fkey FOREIGN KEY (pantry_item_id) REFERENCES public.pantry_items(id) ON DELETE SET NULL;


--
-- Name: meal_plan_items meal_plan_items_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: members members_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: menu_templates menu_templates_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_templates
    ADD CONSTRAINT menu_templates_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: pantry_items pantry_items_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pantry_items
    ADD CONSTRAINT pantry_items_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: pantry_items pantry_items_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pantry_items
    ADD CONSTRAINT pantry_items_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_food_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_food_id_fkey FOREIGN KEY (food_id) REFERENCES public.foods(id) ON DELETE SET NULL;


--
-- Name: recipes recipes_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: saved_products saved_products_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_products
    ADD CONSTRAINT saved_products_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: shopping_items shopping_items_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: weight_log weight_log_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: weight_log weight_log_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: foods; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.foods ENABLE ROW LEVEL SECURITY;

--
-- Name: household_users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.household_users ENABLE ROW LEVEL SECURITY;

--
-- Name: households; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.households ENABLE ROW LEVEL SECURITY;

--
-- Name: meal_plan_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.meal_plan_items ENABLE ROW LEVEL SECURITY;

--
-- Name: members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;

--
-- Name: menu_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.menu_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: pantry_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pantry_items ENABLE ROW LEVEL SECURITY;

--
-- Name: recipe_ingredients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recipe_ingredients ENABLE ROW LEVEL SECURITY;

--
-- Name: recipes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recipes ENABLE ROW LEVEL SECURITY;

--
-- Name: households renombrar mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "renombrar mi hogar" ON public.households FOR UPDATE USING (public.is_household_member(id));


--
-- Name: household_users salir de un hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "salir de un hogar" ON public.household_users FOR DELETE USING ((user_id = auth.uid()));


--
-- Name: saved_products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.saved_products ENABLE ROW LEVEL SECURITY;

--
-- Name: shopping_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shopping_items ENABLE ROW LEVEL SECURITY;

--
-- Name: foods solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.foods USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: meal_plan_items solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.meal_plan_items USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: members solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.members USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: menu_templates solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.menu_templates USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: pantry_items solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.pantry_items USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: recipe_ingredients solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.recipe_ingredients USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: recipes solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.recipes USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: saved_products solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.saved_products USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: shopping_items solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.shopping_items USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: weight_log solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.weight_log USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: households ver mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ver mi hogar" ON public.households FOR SELECT USING (public.is_household_member(id));


--
-- Name: household_users ver quién está en mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ver quién está en mi hogar" ON public.household_users FOR SELECT USING (public.is_household_member(household_id));


--
-- Name: weight_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.weight_log ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict Q4sSaRLYroIXgjILtAY7VKh3qIm6YX3KPHdSLK6X1EgOaNS6kgsG7yviJsZ8CW5

