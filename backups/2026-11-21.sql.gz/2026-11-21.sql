--
-- PostgreSQL database dump
--

\restrict wXJPdaoedpiHp6E2f5esOhZ9NQVOlPQ5ddbUisINMWB6aFvYC3I2T6lMfNRj3IN

-- Dumped from database version 17.12
-- Dumped by pg_dump version 17.12 (Debian 17.12-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: households; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.households (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text DEFAULT 'Mi casa'::text NOT NULL,
    invite_code text DEFAULT upper(substr(replace((gen_random_uuid())::text, '-'::text, ''::text), 1, 8)) NOT NULL,
    created_by uuid DEFAULT auth.uid(),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: create_household(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_household(p_name text DEFAULT 'Mi casa'::text) RETURNS public.households
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
                                                                                                                                                                                                                            declare h public.households;
                                                                                                                                                                                                                            begin
                                                                                                                                                                                                                              if auth.uid() is null then raise exception 'Hay que iniciar sesión'; end if;
                                                                                                                                                                                                                                insert into public.households (name, created_by) values (coalesce(nullif(trim(p_name), ''), 'Mi casa'), auth.uid()) returning * into h;
                                                                                                                                                                                                                                  insert into public.household_users (household_id, user_id, role) values (h.id, auth.uid(), 'admin');
                                                                                                                                                                                                                                    return h;
                                                                                                                                                                                                                                    end $$;


--
-- Name: is_household_member(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_household_member(hid uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
                        select exists (select 1 from public.household_users where household_id = hid and user_id = auth.uid());
                        $$;


--
-- Name: join_household(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.join_household(p_code text) RETURNS public.households
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
                                                                                                                                                                                                                                    declare h public.households;
                                                                                                                                                                                                                                    begin
                                                                                                                                                                                                                                      if auth.uid() is null then raise exception 'Hay que iniciar sesión'; end if;
                                                                                                                                                                                                                                        select * into h from public.households where invite_code = upper(trim(p_code));
                                                                                                                                                                                                                                          if h.id is null then raise exception 'Código no válido'; end if;
                                                                                                                                                                                                                                            insert into public.household_users (household_id, user_id) values (h.id, auth.uid()) on conflict do nothing;
                                                                                                                                                                                                                                              return h;
                                                                                                                                                                                                                                              end $$;


--
-- Name: ping(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.ping() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 'pong'::text;
  $$;


--
-- Name: touch_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.touch_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
                                                                                                                                                                                                begin new.updated_at = now(); return new; end $$;


--
-- Name: foods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.foods (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    brand text,
    store text,
    barcode text,
    kcal numeric(6,1),
    protein_g numeric(5,1),
    carbs_g numeric(5,1),
    sugars_g numeric(5,1),
    fat_g numeric(5,1),
    sat_fat_g numeric(5,1),
    fiber_g numeric(5,1),
    salt_g numeric(5,2),
    source text DEFAULT 'etiqueta'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT foods_source_check CHECK ((source = ANY (ARRAY['etiqueta'::text, 'open_food_facts'::text])))
);


--
-- Name: household_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.household_users (
    household_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text DEFAULT 'miembro'::text NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT household_users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'miembro'::text])))
);


--
-- Name: meal_plan_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meal_plan_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    day date NOT NULL,
    meal text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    recipe_id uuid,
    pantry_item_id uuid,
    eat_out text,
    portions jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT meal_plan_items_check CHECK ((num_nonnulls(recipe_id, pantry_item_id, eat_out) = 1)),
    CONSTRAINT meal_plan_items_eat_out_check CHECK ((eat_out = ANY (ARRAY['ligero'::text, 'normal'::text, 'copioso'::text]))),
    CONSTRAINT meal_plan_items_meal_check CHECK ((meal = ANY (ARRAY['des'::text, 'mm'::text, 'com'::text, 'mer'::text, 'cen'::text])))
);


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    color text DEFAULT '--p1'::text NOT NULL,
    icon text,
    sex text NOT NULL,
    birth_date date NOT NULL,
    is_kid boolean DEFAULT false NOT NULL,
    default_portion numeric(3,2) DEFAULT 1 NOT NULL,
    goal text DEFAULT 'mantener'::text NOT NULL,
    activity text DEFAULT 'baja'::text NOT NULL,
    height_cm numeric(5,1),
    waist_cm numeric(5,1),
    sports jsonb DEFAULT '[]'::jsonb NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT members_default_portion_check CHECK (((default_portion >= (0)::numeric) AND (default_portion <= (2)::numeric))),
    CONSTRAINT members_sex_check CHECK ((sex = ANY (ARRAY['hombre'::text, 'mujer'::text, 'nino'::text, 'nina'::text])))
);


--
-- Name: pantry_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pantry_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    place text NOT NULL,
    qty numeric(7,2) DEFAULT 1 NOT NULL,
    unit text DEFAULT 'ud'::text NOT NULL,
    recipe_id uuid,
    expires_on date,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT pantry_items_place_check CHECK ((place = ANY (ARRAY['Despensa'::text, 'Nevera'::text, 'Congelador'::text]))),
    CONSTRAINT pantry_items_unit_check CHECK ((unit = ANY (ARRAY['raciones'::text, 'g'::text, 'kg'::text, 'ud'::text, 'L'::text, 'paquetes'::text])))
);


--
-- Name: recipe_ingredients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipe_ingredients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    recipe_id uuid NOT NULL,
    food_ref text NOT NULL,
    name text NOT NULL,
    grams numeric(7,1) NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    CONSTRAINT recipe_ingredients_grams_check CHECK ((grams >= (0)::numeric))
);


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recipes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    kind text DEFAULT 'receta'::text NOT NULL,
    food_id uuid,
    servings numeric(4,1) DEFAULT 4 NOT NULL,
    minutes integer,
    meals text[] DEFAULT '{}'::text[] NOT NULL,
    groups text[] DEFAULT '{}'::text[] NOT NULL,
    steps text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT recipes_kind_check CHECK ((kind = ANY (ARRAY['receta'::text, 'precocinado'::text])))
);


--
-- Name: saved_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.saved_products (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    section text NOT NULL
);


--
-- Name: shopping_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shopping_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    name text NOT NULL,
    section text DEFAULT 'Despensa'::text NOT NULL,
    qty numeric(7,2),
    unit text,
    checked boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: weight_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weight_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    household_id uuid NOT NULL,
    member_id uuid NOT NULL,
    day date DEFAULT CURRENT_DATE NOT NULL,
    weight_kg numeric(5,2),
    waist_cm numeric(5,1)
);


--
-- Data for Name: foods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.foods (id, household_id, name, brand, store, barcode, kcal, protein_g, carbs_g, sugars_g, fat_g, sat_fat_g, fiber_g, salt_g, source, updated_at) FROM stdin;
\.


--
-- Data for Name: household_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.household_users (household_id, user_id, role, joined_at) FROM stdin;
ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	14e6fa9a-6fad-42be-abf8-352fb1b1fa39	admin	2026-11-21 15:06:51.178026+00
\.


--
-- Data for Name: households; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.households (id, name, invite_code, created_by, created_at) FROM stdin;
ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Casa	3141C4CC	14e6fa9a-6fad-42be-abf8-352fb1b1fa39	2026-11-21 15:06:51.178026+00
\.


--
-- Data for Name: meal_plan_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meal_plan_items (id, household_id, day, meal, "position", recipe_id, pantry_item_id, eat_out, portions, updated_at) FROM stdin;
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, household_id, name, color, icon, sex, birth_date, is_kid, default_portion, goal, activity, height_cm, waist_cm, sports, "position", updated_at) FROM stdin;
c525a08d-787a-4cb9-b7a8-548a140ce0f2	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Papá	--p1	\N	hombre	1984-03-21	f	1.00	mantener	baja	\N	\N	[]	0	2026-11-21 15:06:51.389804+00
d6d9d46b-1895-470d-85d2-413cf70e83a9	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Mamá	--p2	\N	mujer	1983-01-29	f	0.80	mantener	baja	\N	\N	[]	1	2026-11-21 15:06:51.389804+00
0a416451-d5e0-479a-81d5-94da06c63548	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Fabio	--p3	\N	nino	2018-07-05	t	0.70	crecer	baja	\N	\N	[]	2	2026-11-21 15:06:51.389804+00
bdd2e79b-df45-4574-ad7f-1b87dcbfb8ca	ec3fbb07-7d9d-4f6b-98b9-863718fca2f9	Sergio	--p4	\N	nino	2020-03-25	t	0.60	crecer	baja	\N	\N	[]	3	2026-11-21 15:06:51.389804+00
\.


--
-- Data for Name: pantry_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pantry_items (id, household_id, name, place, qty, unit, recipe_id, expires_on, updated_at) FROM stdin;
\.


--
-- Data for Name: recipe_ingredients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipe_ingredients (id, household_id, recipe_id, food_ref, name, grams, "position") FROM stdin;
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recipes (id, household_id, name, kind, food_id, servings, minutes, meals, groups, steps, updated_at) FROM stdin;
\.


--
-- Data for Name: saved_products; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.saved_products (id, household_id, name, section) FROM stdin;
\.


--
-- Data for Name: shopping_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shopping_items (id, household_id, name, section, qty, unit, checked, updated_at) FROM stdin;
\.


--
-- Data for Name: weight_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.weight_log (id, household_id, member_id, day, weight_kg, waist_cm) FROM stdin;
\.


--
-- Name: foods foods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_pkey PRIMARY KEY (id);


--
-- Name: household_users household_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_users
    ADD CONSTRAINT household_users_pkey PRIMARY KEY (household_id, user_id);


--
-- Name: households households_invite_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_invite_code_key UNIQUE (invite_code);


--
-- Name: households households_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_pkey PRIMARY KEY (id);


--
-- Name: meal_plan_items meal_plan_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: pantry_items pantry_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pantry_items
    ADD CONSTRAINT pantry_items_pkey PRIMARY KEY (id);


--
-- Name: recipe_ingredients recipe_ingredients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: saved_products saved_products_household_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_products
    ADD CONSTRAINT saved_products_household_id_name_key UNIQUE (household_id, name);


--
-- Name: saved_products saved_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_products
    ADD CONSTRAINT saved_products_pkey PRIMARY KEY (id);


--
-- Name: shopping_items shopping_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_pkey PRIMARY KEY (id);


--
-- Name: weight_log weight_log_member_id_day_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_member_id_day_key UNIQUE (member_id, day);


--
-- Name: weight_log weight_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_pkey PRIMARY KEY (id);


--
-- Name: household_users_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX household_users_user_idx ON public.household_users USING btree (user_id);


--
-- Name: meal_plan_items_day_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX meal_plan_items_day_idx ON public.meal_plan_items USING btree (household_id, day);


--
-- Name: recipe_ingredients_recipe_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX recipe_ingredients_recipe_idx ON public.recipe_ingredients USING btree (recipe_id);


--
-- Name: foods foods_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER foods_touch BEFORE UPDATE ON public.foods FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: meal_plan_items meal_plan_items_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER meal_plan_items_touch BEFORE UPDATE ON public.meal_plan_items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: members members_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER members_touch BEFORE UPDATE ON public.members FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: pantry_items pantry_items_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pantry_items_touch BEFORE UPDATE ON public.pantry_items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: recipes recipes_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER recipes_touch BEFORE UPDATE ON public.recipes FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: shopping_items shopping_items_touch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER shopping_items_touch BEFORE UPDATE ON public.shopping_items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();


--
-- Name: foods foods_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: household_users household_users_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_users
    ADD CONSTRAINT household_users_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: household_users household_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.household_users
    ADD CONSTRAINT household_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: households households_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.households
    ADD CONSTRAINT households_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: meal_plan_items meal_plan_items_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: meal_plan_items meal_plan_items_pantry_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_pantry_item_id_fkey FOREIGN KEY (pantry_item_id) REFERENCES public.pantry_items(id) ON DELETE SET NULL;


--
-- Name: meal_plan_items meal_plan_items_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meal_plan_items
    ADD CONSTRAINT meal_plan_items_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: members members_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: pantry_items pantry_items_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pantry_items
    ADD CONSTRAINT pantry_items_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: pantry_items pantry_items_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pantry_items
    ADD CONSTRAINT pantry_items_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE SET NULL;


--
-- Name: recipe_ingredients recipe_ingredients_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: recipe_ingredients recipe_ingredients_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipe_ingredients
    ADD CONSTRAINT recipe_ingredients_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id) ON DELETE CASCADE;


--
-- Name: recipes recipes_food_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_food_id_fkey FOREIGN KEY (food_id) REFERENCES public.foods(id) ON DELETE SET NULL;


--
-- Name: recipes recipes_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: saved_products saved_products_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.saved_products
    ADD CONSTRAINT saved_products_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: shopping_items shopping_items_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shopping_items
    ADD CONSTRAINT shopping_items_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: weight_log weight_log_household_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_household_id_fkey FOREIGN KEY (household_id) REFERENCES public.households(id) ON DELETE CASCADE;


--
-- Name: weight_log weight_log_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weight_log
    ADD CONSTRAINT weight_log_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON DELETE CASCADE;


--
-- Name: foods; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.foods ENABLE ROW LEVEL SECURITY;

--
-- Name: household_users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.household_users ENABLE ROW LEVEL SECURITY;

--
-- Name: households; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.households ENABLE ROW LEVEL SECURITY;

--
-- Name: meal_plan_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.meal_plan_items ENABLE ROW LEVEL SECURITY;

--
-- Name: members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;

--
-- Name: pantry_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pantry_items ENABLE ROW LEVEL SECURITY;

--
-- Name: recipe_ingredients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recipe_ingredients ENABLE ROW LEVEL SECURITY;

--
-- Name: recipes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recipes ENABLE ROW LEVEL SECURITY;

--
-- Name: households renombrar mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "renombrar mi hogar" ON public.households FOR UPDATE USING (public.is_household_member(id));


--
-- Name: household_users salir de un hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "salir de un hogar" ON public.household_users FOR DELETE USING ((user_id = auth.uid()));


--
-- Name: saved_products; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.saved_products ENABLE ROW LEVEL SECURITY;

--
-- Name: shopping_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shopping_items ENABLE ROW LEVEL SECURITY;

--
-- Name: foods solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.foods USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: meal_plan_items solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.meal_plan_items USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: members solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.members USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: pantry_items solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.pantry_items USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: recipe_ingredients solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.recipe_ingredients USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: recipes solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.recipes USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: saved_products solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.saved_products USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: shopping_items solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.shopping_items USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: weight_log solo mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "solo mi hogar" ON public.weight_log USING (public.is_household_member(household_id)) WITH CHECK (public.is_household_member(household_id));


--
-- Name: households ver mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ver mi hogar" ON public.households FOR SELECT USING (public.is_household_member(id));


--
-- Name: household_users ver quién está en mi hogar; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "ver quién está en mi hogar" ON public.household_users FOR SELECT USING (public.is_household_member(household_id));


--
-- Name: weight_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.weight_log ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict wXJPdaoedpiHp6E2f5esOhZ9NQVOlPQ5ddbUisINMWB6aFvYC3I2T6lMfNRj3IN

